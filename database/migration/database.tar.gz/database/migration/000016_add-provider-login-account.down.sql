ALTER TABLE user DROP COLUMN provider_login;
