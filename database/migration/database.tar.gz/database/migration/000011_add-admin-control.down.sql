ALTER TABLE user DROP COLUMN is_admin;
DROP TABLE IF EXISTS email_white_listed;