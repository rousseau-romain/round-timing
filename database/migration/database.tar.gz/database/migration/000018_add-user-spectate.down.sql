ALTER TABLE user_spectate DROP FOREIGN KEY fk_user_spectate_id_user;
ALTER TABLE user_spectate DROP FOREIGN KEY fk_user_spectate_id_user_share;
DROP TABLE user_spectate;
ALTER TABLE user DROP COLUMN id_share;