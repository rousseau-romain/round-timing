ALTER TABLE `match` DROP COLUMN round;

DROP TABLE IF EXISTS match_player_spell;