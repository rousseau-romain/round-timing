ALTER TABLE user DROP COLUMN expired_at;
ALTER TABLE user DROP COLUMN created_at;
ALTER TABLE user DROP COLUMN updated_at;