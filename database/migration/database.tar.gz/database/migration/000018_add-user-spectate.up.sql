ALTER TABLE user ADD id_share CHAR(36) DEFAULT (UUID());
ALTER TABLE user ADD CONSTRAINT UNIQUE (id_share);


CREATE TABLE user_spectate (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_user INT NOT NULL,
    id_user_share CHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

ALTER TABLE user_spectate ADD CONSTRAINT fk_user_spectate_id_user FOREIGN KEY (id_user) REFERENCES user(id);
ALTER TABLE user_spectate ADD CONSTRAINT fk_user_spectate_id_user_share FOREIGN KEY (id_user_share) REFERENCES user(id_share);