ALTER TABLE favorite_spell DROP FOREIGN KEY fk_favorite_spell_id_user;
ALTER TABLE favorite_spell DROP FOREIGN KEY fk_favorite_spell_id_spell;
DROP TABLE favorite_spell;