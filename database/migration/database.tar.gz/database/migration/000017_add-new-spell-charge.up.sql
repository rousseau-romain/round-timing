INSERT INTO spell (id_class, delay) VALUES (13, 6);

INSERT INTO spell_translation (id_language, id_spell, name) VALUES 
(1, 145, "Charge"), 
(2, 145, "Charge"),
(3, 145, "Charge"),
(4, 145, "Charge"),
(5, 145, "Charge");