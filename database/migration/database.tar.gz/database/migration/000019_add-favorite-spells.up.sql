CREATE TABLE favorite_spell (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_user INT NOT NULL,
    id_spell INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

ALTER TABLE favorite_spell ADD CONSTRAINT fk_favorite_spell_id_user FOREIGN KEY (id_user) REFERENCES user(id);
ALTER TABLE favorite_spell ADD CONSTRAINT fk_favorite_spell_id_spell FOREIGN KEY (id_spell) REFERENCES spell(id);